#
# An empty models file so I can use django's testing library
#
